# EVM macOS 安装指南

## 版本信息

- **版本**: 1.5.0
- **支持系统**: macOS 10.14 或更高版本
- **架构**: Intel (x86_64) 和 Apple Silicon (ARM64)

## 安装方法

### 方法一：使用安装脚本（推荐）

1. 解压安装包：
```bash
tar -xzf evm-installer-macos.tar.gz
cd evm-installer-macos
```

2. 运行安装脚本：
```bash
./install.sh
```

3. 验证安装：
```bash
evm --version
evm --help
```

### 方法二：使用 PKG 安装包

1. 双击 `evm-1.5.0-macos.pkg` 文件
2. 按照安装向导完成安装
3. 在终端中验证：`evm --version`

### 方法三：手动安装

```bash
# 复制可执行文件
sudo cp evm /usr/local/bin/
sudo chmod +x /usr/local/bin/evm

# 验证
evm --version
```

## 卸载

```bash
# 使用安装脚本卸载
./install.sh --uninstall

# 或者手动卸载
sudo rm -f /usr/local/bin/evm
rm -rf ~/.evm  # 删除数据（可选）
```

## 文件说明

- `evm` - EVM 可执行文件
- `install.sh` - 安装脚本
- `README.md` - 使用说明
- `LICENSE` - 许可证

## 快速开始

```bash
# 设置环境变量
evm set API_KEY your_secret_key

# 获取环境变量
evm get API_KEY

# 列出所有变量
evm list

# 导出到 .env 文件
evm export --format env -o .env
```

## 支持

如有问题，请访问：https://github.com/zxygithub/evm
