#!/bin/bash
# =============================================================================
# EVM macOS 安装脚本
# Version: 1.5.0
# =============================================================================

set -e

EVM_VERSION="1.5.0"
INSTALL_DIR="/usr/local/bin"
EVM_BIN="evm"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 打印信息函数
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查系统
check_system() {
    if [[ "$OSTYPE" != "darwin"* ]]; then
        print_error "此安装程序仅支持 macOS 系统"
        exit 1
    fi
    
    print_info "检测到 macOS 系统"
    print_info "架构: $(uname -m)"
    print_info "版本: $(sw_vers -productVersion)"
}

# 安装 EVM
install_evm() {
    print_info "开始安装 EVM v${EVM_VERSION}..."
    
    # 检查安装目录
    if [[ ! -d "$INSTALL_DIR" ]]; then
        print_info "创建安装目录: $INSTALL_DIR"
        sudo mkdir -p "$INSTALL_DIR"
    fi
    
    # 复制可执行文件
    print_info "复制 evm 到 $INSTALL_DIR"
    sudo cp "$EVM_BIN" "$INSTALL_DIR/"
    sudo chmod +x "$INSTALL_DIR/$EVM_BIN"
    
    # 验证安装
    if [[ -x "$INSTALL_DIR/$EVM_BIN" ]]; then
        INSTALLED_VERSION=$("$INSTALL_DIR/$EVM_BIN" --version 2>/dev/null || echo "unknown")
        print_info "安装成功!"
        print_info "版本: $INSTALLED_VERSION"
        print_info "安装位置: $INSTALL_DIR/$EVM_BIN"
    else
        print_error "安装失败，无法执行 evm"
        exit 1
    fi
}

# 检查 PATH
check_path() {
    if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
        print_warning "$INSTALL_DIR 不在 PATH 中"
        print_info "请添加以下行到 ~/.zshrc 或 ~/.bash_profile:"
        echo "export PATH=\"$INSTALL_DIR:\$PATH\""
    else
        print_info "PATH 检查通过"
    fi
}

# 创建数据目录
create_data_dir() {
    EVM_DATA_DIR="$HOME/.evm"
    if [[ ! -d "$EVM_DATA_DIR" ]]; then
        print_info "创建数据目录: $EVM_DATA_DIR"
        mkdir -p "$EVM_DATA_DIR"
    fi
}

# 打印使用说明
print_usage() {
    echo ""
    echo "=========================================="
    echo "EVM v${EVM_VERSION} 安装完成!"
    echo "=========================================="
    echo ""
    echo "快速开始:"
    echo "  evm --help              显示帮助信息"
    echo "  evm --version           显示版本信息"
    echo "  evm set KEY VALUE       设置环境变量"
    echo "  evm get KEY             获取环境变量"
    echo "  evm list                列出所有变量"
    echo ""
    echo "示例:"
    echo "  evm set API_KEY abc123"
    echo "  evm get API_KEY"
    echo "  evm export --format env"
    echo ""
    echo "更多信息请查看 README.md"
    echo "=========================================="
}

# 卸载函数
uninstall() {
    print_info "卸载 EVM..."
    if [[ -f "$INSTALL_DIR/$EVM_BIN" ]]; then
        sudo rm -f "$INSTALL_DIR/$EVM_BIN"
        print_info "EVM 已卸载"
    else
        print_warning "EVM 未安装"
    fi
    
    read -p "是否删除数据目录 ~/.evm? (y/N): " confirm
    if [[ $confirm == [yY] ]]; then
        rm -rf "$HOME/.evm"
        print_info "数据目录已删除"
    fi
    
    exit 0
}

# 主函数
main() {
    # 检查参数
    if [[ "$1" == "--uninstall" ]] || [[ "$1" == "-u" ]]; then
        uninstall
    fi
    
    if [[ "$1" == "--help" ]] || [[ "$1" == "-h" ]]; then
        echo "EVM macOS 安装程序 v${EVM_VERSION}"
        echo ""
        echo "用法:"
        echo "  ./install.sh          安装 EVM"
        echo "  ./install.sh -u       卸载 EVM"
        echo "  ./install.sh -h       显示帮助"
        exit 0
    fi
    
    echo "=========================================="
    echo "EVM macOS 安装程序 v${EVM_VERSION}"
    echo "=========================================="
    echo ""
    
    check_system
    echo ""
    install_evm
    echo ""
    check_path
    echo ""
    create_data_dir
    echo ""
    print_usage
}

# 运行主函数
main "$@"
